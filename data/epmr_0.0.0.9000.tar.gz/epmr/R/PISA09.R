#' PISA 2009 Data
#'
#' A dataset containing demographic, cognitive, and noncognitive variables
#' for a subset of students participating in the 2009 administration of the
#' Programme for International Student Assessment (PISA).
#'
#' Variables include
#' \itemize{
#'  \item cnt: country code factor.
#'  \item schoolid: school ID factor.
#'  \item stidstd: student ID factor.
#'  \item oecd: indicator factor for OECD participation.
#'  \item bookid: booklet ID factor.
#'  \item age: numeric age in years.
#'  \item grade: numeric grade, ranging from 7 to 12
#'  \item From the PISA 2009 student survey:
#'  \itemize{
#'    \item st27q01 through st27q13: items from the approaches to learning scale,
#'      which is separated into three subscales: memorization (items st27q01,
#'      st27q03, st27q05, st27q07), elaboration (items st27q04, st27q08,
#'      st27q10, st27q12), and control strategies (items st27q02, st27q06,
#'      st27q09, st27q11, st27q13).
#'    \item st33q01 through st33q04: items from the attitude toward school scale.
#'    \item st41q01 through st41q06: items from the metacognition understanding
#'      and remembering scale.
#'    \item st42q01 through st42q05: items from the metacognition summarizing
#'      scale.
#'    \item memor: memorization strategies scale score.
#'    \item elab: elaboration strategies scale score.
#'    \item cstrat: control strategies scale score.
#'    \item atschl: attitude toward school scale score.
#'    \item undrem: metacognition understanding and remembering scale score.
#'    \item metasum: metacognition summarizing scale score.
#'  }
#'  \item From the PISA 2009 reading assessment:
#'  \itemize{
#'    \item r414q02 through r458q04: unscored responses for 11 items.
#'    \item r414q02s through r458q04s: scored responses for 11 items.
#'  }
#'}
#'
#' @format A data frame with 44878 rows and 63 variables
#' @source \url{https://nces.ed.gov/surveys/pisa/}
"PISA09"
